import UIKit

var billsArray: [String] = ["Pokemon", "cards", "pens", "jewelry"]

